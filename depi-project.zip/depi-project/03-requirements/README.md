# 3. Requirements Gathering

**Deadline:** 16 Oct 2026

## Checklist
- [ ] Stakeholder Analysis
- [ ] User Stories & Use Cases
- [ ] Functional Requirements
- [ ] Non-functional Requirements (performance, security, usability, reliability)

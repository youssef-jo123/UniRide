# 2. Literature Review

**Deadline:** 16 Oct 2026

## Checklist
- [ ] Feedback & Evaluation (lecturer's assessment)
- [ ] Suggested Improvements
- [ ] Final Grading Criteria (documentation, implementation, testing, presentation)

# 4. System Analysis & Design

**Deadline:** 6 Nov 2026

## Checklist
- [ ] Problem Statement & Objectives
- [ ] Use Case Diagram & Descriptions
- [ ] Software Architecture (MVC / Microservices ...)
- [ ] ER Diagram + Logical & Physical Schema
- [ ] DFD (context + detailed)
- [ ] Sequence Diagrams
- [ ] Activity Diagram
- [ ] State Diagram
- [ ] Class Diagram
- [ ] Wireframes & Mockups + UI/UX Guidelines
- [ ] Technology Stack
- [ ] Deployment Diagram
- [ ] Component Diagram
- [ ] Additional (if applicable): API docs, testing plan, deployment strategy
